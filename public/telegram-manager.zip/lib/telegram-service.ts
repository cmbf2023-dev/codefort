/**
 * Telegram Service - Handles MTProto API interactions
 * Wraps Telegram Bot API calls for group cloning operations
 */

interface TelegramMessage {
  message_id: number
  from?: {
    id: number
    first_name: string
    last_name?: string
    username?: string
  }
  text?: string
  caption?: string
  photo?: Array<any>
  document?: any
  video?: any
  audio?: any
  voice?: any
  reply_to_message_id?: number
}

interface CopyMessageParams {
  chat_id: number | string
  from_chat_id: number | string
  message_id: number
  caption?: string
  parse_mode?: string
}

export class TelegramService {
  private botToken: string
  private apiBaseUrl = 'https://api.telegram.org'

  constructor(botToken: string) {
    if (!botToken) {
      throw new Error('Bot token is required')
    }
    this.botToken = botToken
  }

  /**
   * Copy message from source group to destination (preserves original sender)
   */
  async copyMessage(params: CopyMessageParams): Promise<number> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/copyMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      console.log('[v0] Message copied successfully:', data.result.message_id)
      return data.result.message_id
    } catch (error) {
      console.error('[v0] Copy message error:', error)
      throw error
    }
  }

  /**
   * Forward message from source to destination
   */
  async forwardMessage(
    chatId: number | string,
    fromChatId: number | string,
    messageId: number
  ): Promise<number> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/forwardMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          from_chat_id: fromChatId,
          message_id: messageId,
        }),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result.message_id
    } catch (error) {
      console.error('[v0] Forward message error:', error)
      throw error
    }
  }

  /**
   * Add user to group silently (without notification)
   */
  async addChatMember(
    chatId: number | string,
    userId: number,
    options?: { expires_in?: number }
  ): Promise<boolean> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/addChatMember`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          user_id: userId,
          ...options,
        }),
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      return data.ok
    } catch (error) {
      console.error('[v0] Add chat member error:', error)
      throw error
    }
  }

  /**
   * Get chat members count
   */
  async getChatMembersCount(chatId: number | string): Promise<number> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/bot${this.botToken}/getChatMembersCount?chat_id=${chatId}`
      )

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result
    } catch (error) {
      console.error('[v0] Get chat members count error:', error)
      throw error
    }
  }

  /**
   * Get chat info
   */
  async getChat(chatId: number | string): Promise<any> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/bot${this.botToken}/getChat?chat_id=${chatId}`)

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`)
      }

      const data = await response.json()
      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description}`)
      }

      return data.result
    } catch (error) {
      console.error('[v0] Get chat error:', error)
      throw error
    }
  }
}

export function getTelegramService(): TelegramService {
  const botToken = process.env.TELEGRAM_BOT_TOKEN
  if (!botToken) {
    throw new Error('TELEGRAM_BOT_TOKEN environment variable is not set')
  }
  return new TelegramService(botToken)
}
