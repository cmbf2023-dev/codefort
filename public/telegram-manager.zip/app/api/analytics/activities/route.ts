import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Get recent activities for monitoring
 */
export async function GET(request: NextRequest) {
  try {
    const limit = parseInt(request.nextUrl.searchParams.get('limit') || '10', 10)
    const userId = request.headers.get('x-user-id') || 'demo-user'

    console.log('[v0] Fetching recent activities:', { limit, userId })

    const activities = await queries.getRecentActivities(userId, limit)

    const enrichedActivities = (activities || []).map((act: any) => ({
      id: act.id,
      action: act.operation,
      groupId: act.group_id,
      groupName: act.groups?.destination_group_name || 'Unknown Group',
      status: act.status,
      timestamp: act.created_at,
      details: act.details,
      errorMessage: act.error_message,
    }))

    return NextResponse.json({ success: true, activities: enrichedActivities })
  } catch (error) {
    console.error('[v0] Activities fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch activities', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
