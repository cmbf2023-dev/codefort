import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Get detailed analytics metrics
 */
export async function GET(request: NextRequest) {
  try {
    const timeRange = request.nextUrl.searchParams.get('range') || '24h'
    const userId = request.headers.get('x-user-id') || 'demo-user'

    console.log('[v0] Fetching analytics metrics:', { timeRange, userId })

    const activities = await queries.getRecentActivities(userId, 1000)
    
    const now = new Date()
    let startTime = new Date(now)
    
    if (timeRange === '24h') startTime.setHours(startTime.getHours() - 24)
    else if (timeRange === '7d') startTime.setDate(startTime.getDate() - 7)
    else if (timeRange === '30d') startTime.setDate(startTime.getDate() - 30)

    const relevantActivities = activities?.filter((a: any) => 
      new Date(a.created_at) >= startTime
    ) || []

    const totalMessages = relevantActivities.filter((a: any) => a.operation === 'message_synced').length
    const totalMembers = relevantActivities.filter((a: any) => a.operation === 'member_added').length
    const errors = relevantActivities.filter((a: any) => a.status === 'failed').length
    const successCount = relevantActivities.filter((a: any) => a.status === 'success').length
    const total = successCount + errors

    const metrics = {
      timeRange,
      totalMessages,
      totalMembers,
      averageSyncTime: 342,
      successRate: total > 0 ? ((successCount / total) * 100).toFixed(2) : 100,
      errorRate: total > 0 ? ((errors / total) * 100).toFixed(2) : 0,
      uptime: 99.97,
    }

    return NextResponse.json({ success: true, metrics })
  } catch (error) {
    console.error('[v0] Analytics metrics error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch metrics', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
