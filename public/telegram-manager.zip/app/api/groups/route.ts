import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Get all groups for authenticated user
 */
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'
    
    const groups = await queries.getUserGroups(userId)

    const enrichedGroups = groups.map((group: any) => ({
      id: group.id,
      sourceGroupId: group.source_group_id,
      destinationGroupId: group.destination_group_id,
      name: group.destination_group_name || group.destination_group_id,
      original: group.source_group_name || group.source_group_id,
      status: group.status,
      method: group.clone_method,
      members: group.total_members,
      synced: group.cloned_members,
      createdAt: group.created_at,
    }))

    return NextResponse.json({ success: true, groups: enrichedGroups })
  } catch (error) {
    console.error('[v0] Groups fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch groups', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
