import { NextRequest, NextResponse } from 'next/server'
import { getSyncManager } from '@/lib/sync-manager'
import { getTelegramService } from '@/lib/telegram-service'
import { createClient } from '@/lib/supabase/server'
import * as queries from '@/lib/supabase/queries'

/**
 * History Cloning Endpoint
 * Batch processes historical messages with scheduling support
 * Based on Telethon's getMessages pagination pattern
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sourceGroupId, destGroupId, batchSize = 100, preserveSenders, silentAdd, userId } = body

    if (!sourceGroupId || !destGroupId) {
      return NextResponse.json(
        { error: 'Source and destination group IDs are required' },
        { status: 400 }
      )
    }

    if (batchSize < 10 || batchSize > 500) {
      return NextResponse.json(
        { error: 'Batch size must be between 10 and 500' },
        { status: 400 }
      )
    }

    console.log('[v0] History clone initiated:', {
      source: sourceGroupId,
      dest: destGroupId,
      batchSize,
    })

    const telegramService = getTelegramService()
    const syncManager = getSyncManager()
    const supabase = await createClient()

    try {
      const sourceChat = await telegramService.getChat(sourceGroupId)
      await telegramService.getChat(destGroupId)

      console.log('[v0] Source chat info:', {
        title: sourceChat.title,
        type: sourceChat.type,
      })
    } catch (error) {
      console.error('[v0] Group validation failed:', error)
      return NextResponse.json(
        { error: 'Unable to access one or both groups' },
        { status: 400 }
      )
    }

    const totalMessages = sourceChat.message_count || 0

    const group = await queries.createGroup(userId, {
      sourceGroupId,
      destinationGroupId: destGroupId,
      sourceGroupName: sourceChat.title,
      destinationGroupName: body.destGroupName,
      cloneMethod: 'history',
    })

    const job = await queries.createCloneJob(group.id, 'history', totalMessages)

    console.log('[v0] History clone initiated:', {
      source: sourceGroupId,
      dest: destGroupId,
      totalMessages,
      groupId: group.id,
      jobId: job.id,
    })

    const syncJob = {
      jobId: job.id,
      sourceGroupId,
      destGroupId,
      method: 'history' as const,
      preserveSenders: preserveSenders ?? true,
      silentAdd: silentAdd ?? true,
      userId: userId,
      createdAt: new Date(),
    }

    await syncManager.startHistoryClone(syncJob)

    return NextResponse.json({
      success: true,
      jobId: job.id,
      groupId: group.id,
      status: 'queued',
      method: 'history',
      sourceGroupId,
      destGroupId,
      batchSize,
      totalMessages,
      createdAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error('[v0] History clone error:', error)
    return NextResponse.json(
      {
        error: 'Failed to initiate history clone',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
