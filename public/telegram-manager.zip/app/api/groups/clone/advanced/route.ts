import { NextRequest, NextResponse } from 'next/server'
import { getSyncManager } from '@/lib/sync-manager'
import { getTelegramService } from '@/lib/telegram-service'
import { createClient } from '@/lib/supabase/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Advanced Clone Endpoint
 * Clones entire message history preserving original sender names using copyMessage
 * Based on Pyrogram's message.copy() pattern
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sourceGroupId, destGroupId, preserveSenders, silentAdd, userId } = body

    if (!sourceGroupId || !destGroupId) {
      return NextResponse.json(
        { error: 'Source and destination group IDs are required' },
        { status: 400 }
      )
    }

    if (typeof sourceGroupId !== 'string' && typeof sourceGroupId !== 'number') {
      return NextResponse.json(
        { error: 'Invalid source group ID format' },
        { status: 400 }
      )
    }

    console.log('[v0] Advanced clone initiated:', {
      source: sourceGroupId,
      dest: destGroupId,
      preserveSenders,
      silentAdd,
    })

    const telegramService = getTelegramService()
    const syncManager = getSyncManager()

    try {
      // Validate source group exists and is accessible
      await telegramService.getChat(sourceGroupId)
      await telegramService.getChat(destGroupId)
    } catch (error) {
      console.error('[v0] Group validation failed:', error)
      return NextResponse.json(
        { error: 'Unable to access one or both groups. Verify group IDs and bot permissions.' },
        { status: 400 }
      )
    }

    const supabase = await createClient()
    
    const group = await queries.createGroup(userId, {
      sourceGroupId,
      destinationGroupId: destGroupId,
      sourceGroupName: body.sourceGroupName,
      destinationGroupName: body.destGroupName,
      cloneMethod: 'advanced',
    })

    const job = await queries.createCloneJob(group.id, 'advanced', 0)

    console.log('[v0] Advanced clone initiated:', {
      source: sourceGroupId,
      dest: destGroupId,
      groupId: group.id,
      jobId: job.id,
    })

    const syncJob = {
      jobId: job.id,
      sourceGroupId,
      destGroupId,
      method: 'advanced' as const,
      preserveSenders,
      silentAdd,
      userId,
      createdAt: new Date(),
    }

    await syncManager.startAdvancedClone(syncJob)

    return NextResponse.json({
      success: true,
      jobId: job.id,
      groupId: group.id,
      status: 'running',
      method: 'advanced',
      sourceGroupId,
      destGroupId,
      preserveSenders,
      silentAdd,
      createdAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error('[v0] Advanced clone error:', error)
    return NextResponse.json(
      {
        error: 'Failed to initiate advanced clone',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
