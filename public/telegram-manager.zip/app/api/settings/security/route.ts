import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

/**
 * Get security settings
 */
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'

    const settings = await queries.getUserSettings(userId)

    const security = {
      twoFactorEnabled: settings?.settings_json?.twoFactorEnabled || false,
      activeSessions: 1,
      lastLogin: settings?.updated_at || new Date().toISOString(),
      accountCreated: settings?.created_at || new Date().toISOString(),
    }

    return NextResponse.json({ success: true, security })
  } catch (error) {
    console.error('[v0] Security settings fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch security settings', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

/**
 * Update security settings
 */
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'
    const body = await request.json()
    const { action } = body

    console.log('[v0] Security action:', action)

    if (action === 'enable2fa') {
      await queries.updateUserSettings(userId, {
        settings_json: { twoFactorEnabled: true },
      })
    } else if (action === 'disable2fa') {
      await queries.updateUserSettings(userId, {
        settings_json: { twoFactorEnabled: false },
      })
    } else if (action === 'revokeSession') {
      // In production, implement session revocation logic
      console.log('[v0] Session revoked for user:', userId)
    }

    return NextResponse.json({
      success: true,
      message: `Security setting updated: ${action}`,
    })
  } catch (error) {
    console.error('[v0] Security update error:', error)
    return NextResponse.json(
      { error: 'Failed to update security settings', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
