import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'

interface NotificationSettings {
  cloneCompletion: boolean
  syncFailures: boolean
  errorRateAlerts: boolean
  memberLimitAlerts: boolean
}

/**
 * Get notification preferences
 */
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'

    const settings = await queries.getUserSettings(userId)

    const notificationSettings: NotificationSettings = {
      cloneCompletion: settings?.settings_json?.cloneCompletion !== false,
      syncFailures: settings?.settings_json?.syncFailures !== false,
      errorRateAlerts: settings?.settings_json?.errorRateAlerts !== false,
      memberLimitAlerts: settings?.settings_json?.memberLimitAlerts !== false,
    }

    return NextResponse.json({ success: true, settings: notificationSettings })
  } catch (error) {
    console.error('[v0] Notifications fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch notification settings', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

/**
 * Update notification preferences
 */
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'
    const body: NotificationSettings = await request.json()

    console.log('[v0] Updating notification settings:', body)

    await queries.updateUserSettings(userId, {
      settings_json: body,
    })

    return NextResponse.json({
      success: true,
      message: 'Notification settings updated',
    })
  } catch (error) {
    console.error('[v0] Notifications update error:', error)
    return NextResponse.json(
      { error: 'Failed to update notification settings', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
