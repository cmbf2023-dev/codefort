import { NextRequest, NextResponse } from 'next/server'
import * as queries from '@/lib/supabase/queries'
import crypto from 'crypto'

/**
 * Get API keys configuration
 */
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'

    const settings = await queries.getUserSettings(userId)

    const config = {
      botTokenConfigured: !!settings?.settings_json?.botToken,
      webhookUrlConfigured: !!settings?.webhook_url,
      webhookTokenExists: !!settings?.webhook_token,
      maxConcurrentGroups: settings?.max_concurrent_groups || 20,
      batchSize: settings?.batch_size || 50,
      lastUpdated: settings?.updated_at || new Date().toISOString(),
    }

    return NextResponse.json({ success: true, config })
  } catch (error) {
    console.error('[v0] Settings fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch settings', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

/**
 * Update API configuration
 */
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id') || 'demo-user'
    const body = await request.json()
    const { maxConcurrentGroups, batchSize, botToken, webhookUrl } = body

    console.log('[v0] Updating API configuration')

    if (maxConcurrentGroups && (maxConcurrentGroups < 1 || maxConcurrentGroups > 20)) {
      return NextResponse.json(
        { error: 'Max concurrent groups must be between 1 and 20' },
        { status: 400 }
      )
    }

    if (batchSize && (batchSize < 10 || batchSize > 500)) {
      return NextResponse.json(
        { error: 'Batch size must be between 10 and 500' },
        { status: 400 }
      )
    }

    const settingsJson = {
      botToken: botToken ? crypto.createHash('sha256').update(botToken).digest('hex') : undefined,
    }

    await queries.updateUserSettings(userId, {
      max_concurrent_groups: maxConcurrentGroups || 20,
      batch_size: batchSize || 50,
      webhook_url: webhookUrl,
      settings_json: settingsJson,
    })

    return NextResponse.json({
      success: true,
      message: 'API configuration updated successfully',
    })
  } catch (error) {
    console.error('[v0] Settings update error:', error)
    return NextResponse.json(
      { error: 'Failed to update settings', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
