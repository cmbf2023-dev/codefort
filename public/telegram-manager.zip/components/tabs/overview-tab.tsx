'use client'

import { useEffect, useState } from 'react'
import { Card } from '@/components/ui/card'
import { Activity, Users, Copy, AlertCircle, Loader } from 'lucide-react'

interface Stats {
  activeClones: number
  totalGroups: number
  messagesSynced: number
  successRate: number
  loading: boolean
}

interface RecentJob {
  id: string
  status: string
  group_name: string
  timestamp: string
}

export function OverviewTab() {
  const [stats, setStats] = useState<Stats>({
    activeClones: 0,
    totalGroups: 0,
    messagesSynced: 0,
    successRate: 0,
    loading: true,
  })

  const [recentJobs, setRecentJobs] = useState<RecentJob[]>([])

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch('/api/analytics/metrics', {
          headers: {
            'x-user-id': 'user-123',
          },
        })
        if (response.ok) {
          const data = await response.json()
          setStats({
            activeClones: data.activeClones || 0,
            totalGroups: data.totalGroups || 0,
            messagesSynced: data.messagesSynced || 0,
            successRate: data.successRate || 0,
            loading: false,
          })
        }
      } catch (error) {
        console.error('[v0] Failed to fetch stats:', error)
        setStats((prev) => ({ ...prev, loading: false }))
      }
    }

    fetchStats()
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const fetchRecentJobs = async () => {
      try {
        const response = await fetch('/api/analytics/activities', {
          headers: {
            'x-user-id': 'user-123',
          },
        })
        if (response.ok) {
          const data = await response.json()
          setRecentJobs(data.slice(0, 4))
        }
      } catch (error) {
        console.error('[v0] Failed to fetch recent jobs:', error)
      }
    }

    fetchRecentJobs()
  }, [])

  const statCards = [
    { label: 'Active Clones', value: stats.activeClones, icon: Copy, color: 'bg-primary' },
    { label: 'Total Groups', value: stats.totalGroups, icon: Users, color: 'bg-accent' },
    { label: 'Messages Synced', value: `${(stats.messagesSynced / 1000).toFixed(1)}K`, icon: Activity, color: 'bg-primary' },
    { label: 'Success Rate', value: `${stats.successRate}%`, icon: AlertCircle, color: 'bg-accent' },
  ]

  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-card-foreground mb-2">Overview</h2>
        <p className="text-muted-foreground">Real-time statistics and cloning status</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium">{stat.label}</p>
                  <p className="text-3xl font-bold mt-2 text-card-foreground">
                    {stats.loading ? <Loader className="h-6 w-6 animate-spin" /> : stat.value}
                  </p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <h3 className="font-bold text-lg mb-4 text-card-foreground">Clone History</h3>
          <div className="space-y-3">
            {recentJobs.length === 0 ? (
              <p className="text-sm text-muted-foreground">No clone jobs yet</p>
            ) : (
              recentJobs.map((job) => (
                <div key={job.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <div>
                      <p className="text-sm font-medium text-card-foreground">{job.group_name}</p>
                      <p className="text-xs text-muted-foreground">{job.timestamp}</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-1 bg-primary text-primary-foreground rounded-full">
                    {job.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-lg mb-4 text-card-foreground">System Status</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">API Status</span>
              <span className="text-xs px-2 py-1 bg-green-500/20 text-green-700 dark:text-green-400 rounded-full">
                Operational
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Webhook</span>
              <span className="text-xs px-2 py-1 bg-green-500/20 text-green-700 dark:text-green-400 rounded-full">
                Active
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Database</span>
              <span className="text-xs px-2 py-1 bg-green-500/20 text-green-700 dark:text-green-400 rounded-full">
                Connected
              </span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
