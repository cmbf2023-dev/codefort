'use client'

import { useEffect, useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Plus, MoreVertical, Pause, Trash2, Loader } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Group {
  id: string
  name: string
  original_group_id: number
  destination_group_id: number
  status: 'active' | 'syncing' | 'paused' | 'failed'
  member_count: number
  sync_progress: number
  created_at: string
}

export function GroupsTab() {
  const [groups, setGroups] = useState<Group[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await fetch('/api/groups', {
          headers: {
            'x-user-id': 'user-123', // Replace with actual user ID from session
          },
        })
        if (response.ok) {
          const data = await response.json()
          setGroups(data)
        } else {
          console.error('[v0] Failed to fetch groups:', response.status)
          setGroups([])
        }
      } catch (error) {
        console.error('[v0] Error fetching groups:', error)
        toast({
          title: 'Error',
          description: 'Failed to load groups',
          variant: 'destructive',
        })
      } finally {
        setLoading(false)
      }
    }

    fetchGroups()
    const interval = setInterval(fetchGroups, 10000) // Refresh every 10s
    return () => clearInterval(interval)
  }, [toast])

  const handlePause = async (groupId: string) => {
    try {
      const response = await fetch(`/api/groups/${groupId}/pause`, {
        method: 'POST',
        headers: {
          'x-user-id': 'user-123',
        },
      })
      if (response.ok) {
        setGroups((prev) =>
          prev.map((g) => (g.id === groupId ? { ...g, status: 'paused' } : g))
        )
        toast({
          title: 'Success',
          description: 'Group paused',
        })
      }
    } catch (error) {
      console.error('[v0] Error pausing group:', error)
      toast({
        title: 'Error',
        description: 'Failed to pause group',
        variant: 'destructive',
      })
    }
  }

  const handleDelete = async (groupId: string) => {
    try {
      const response = await fetch(`/api/groups/${groupId}`, {
        method: 'DELETE',
        headers: {
          'x-user-id': 'user-123',
        },
      })
      if (response.ok) {
        setGroups((prev) => prev.filter((g) => g.id !== groupId))
        toast({
          title: 'Success',
          description: 'Group deleted',
        })
      }
    } catch (error) {
      console.error('[v0] Error deleting group:', error)
      toast({
        title: 'Error',
        description: 'Failed to delete group',
        variant: 'destructive',
      })
    }
  }

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-card-foreground">Groups</h2>
          <p className="text-muted-foreground">Manage your cloned groups</p>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-2" />
          New Clone
        </Button>
      </div>

      {loading ? (
        <Card className="p-8 flex items-center justify-center">
          <Loader className="h-6 w-6 animate-spin text-primary" />
        </Card>
      ) : groups.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No cloned groups yet. Start by creating a new clone.</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {groups.map((group) => (
            <Card key={group.id} className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="font-bold text-lg text-card-foreground">{group.name}</h3>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        group.status === 'active'
                          ? 'bg-green-500/20 text-green-700 dark:text-green-400'
                          : group.status === 'syncing'
                          ? 'bg-blue-500/20 text-blue-700 dark:text-blue-400'
                          : group.status === 'paused'
                          ? 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400'
                          : 'bg-red-500/20 text-red-700 dark:text-red-400'
                      }`}
                    >
                      {group.status.charAt(0).toUpperCase() + group.status.slice(1)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    From: <span className="font-medium">Group {group.original_group_id}</span>
                  </p>
                  <div className="flex items-center gap-6 text-sm">
                    <div>
                      <span className="text-muted-foreground">Members: </span>
                      <span className="font-medium text-card-foreground">{group.member_count}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Progress: </span>
                      <span className="font-medium text-card-foreground">{group.sync_progress}%</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handlePause(group.id)}
                    disabled={group.status === 'paused'}
                  >
                    <Pause className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(group.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
