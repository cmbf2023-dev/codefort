'use client'

import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { TrendingUp, MessageCircle, Users, Clock, Activity, BarChart3, Loader } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'

export function AnalyticsTab() {
  const [timeRange, setTimeRange] = useState('24h')
  const [chartData, setChartData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [metricsData, setMetricsData] = useState<any[]>([])

  useEffect(() => {
    const fetchChartData = async () => {
      try {
        const response = await fetch(`/api/analytics/chart-data?range=${timeRange}`, {
          headers: {
            'x-user-id': 'user-123',
          },
        })
        if (response.ok) {
          const data = await response.json()
          setChartData(data.chartData || [])
          setMetricsData(data.metrics || [])
        }
      } catch (error) {
        console.error('[v0] Failed to fetch chart data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchChartData()
  }, [timeRange])

  const performanceMetrics = [
    { metric: 'Success Rate', value: '99.2%', target: '99%', status: 'excellent' },
    { metric: 'Error Rate', value: '0.8%', target: '< 1%', status: 'good' },
    { metric: 'Avg Response', value: '234ms', target: '< 500ms', status: 'excellent' },
    { metric: 'Sync Latency', value: '156ms', target: '< 200ms', status: 'good' },
  ]

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center">
        <Loader className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-card-foreground mb-2">Analytics & Monitoring</h2>
          <p className="text-muted-foreground">Real-time performance metrics and cloning statistics</p>
        </div>
        <div className="flex gap-2">
          {['24h', '7d', '30d'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                timeRange === range
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-card-foreground hover:bg-secondary/80'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {metricsData.map((metric) => {
          const Icon = metric.icon || MessageCircle
          return (
            <Card key={metric.label} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-muted-foreground text-sm font-medium">{metric.label}</p>
                  <p className="text-3xl font-bold text-card-foreground mt-2">{metric.value}</p>
                </div>
                <div className="bg-primary p-3 rounded-lg">
                  <Icon className="h-5 w-5 text-white" />
                </div>
              </div>
              <p className="text-xs text-green-600 dark:text-green-400 font-medium">{metric.trend}</p>
            </Card>
          )
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Message Activity */}
        {chartData.length > 0 && (
          <>
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4 text-card-foreground flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Message Activity
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="time" stroke="var(--color-muted-foreground)" />
                  <YAxis stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--color-card)',
                      border: '1px solid var(--color-border)',
                      borderRadius: '8px',
                      color: 'var(--color-card-foreground)',
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="messages" stroke="var(--color-primary)" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            {/* Member Growth */}
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4 text-card-foreground flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Member Growth
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="time" stroke="var(--color-muted-foreground)" />
                  <YAxis stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--color-card)',
                      border: '1px solid var(--color-border)',
                      borderRadius: '8px',
                      color: 'var(--color-card-foreground)',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="members" fill="var(--color-accent)" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </>
        )}
      </div>

      {/* Performance Metrics */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-6 text-card-foreground">Performance Metrics</h3>
        <div className="space-y-4">
          {performanceMetrics.map((item) => (
            <div key={item.metric} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
              <div className="flex-1">
                <p className="text-sm font-medium text-card-foreground mb-1">{item.metric}</p>
                <p className="text-xs text-muted-foreground">Target: {item.target}</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-lg font-bold text-card-foreground">{item.value}</p>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      item.status === 'excellent'
                        ? 'bg-green-500/20 text-green-700 dark:text-green-400'
                        : 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400'
                    }`}
                  >
                    {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Recent Activities */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-4 text-card-foreground">Recent Activities</h3>
        <div className="space-y-3">
          {/* Activities will be fetched from /api/analytics/activities */}
          <p className="text-sm text-muted-foreground">Activities loading from real-time database...</p>
        </div>
      </Card>
    </div>
  )
}
