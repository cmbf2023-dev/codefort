import { Copy, BarChart3, Settings, Database, Zap, HelpCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface SidebarProps {
  isOpen: boolean
  activeTab: string
  setActiveTab: (tab: string) => void
}

export function Sidebar({ isOpen, activeTab, setActiveTab }: SidebarProps) {
  const menuItems = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'groups', label: 'Groups', icon: Copy },
    { id: 'cloning', label: 'Clone Group', icon: Zap },
    { id: 'analytics', label: 'Analytics', icon: Database },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'help', label: 'Help', icon: HelpCircle },
  ]

  return (
    <aside className={`bg-card border-r border-border transition-all duration-300 ${isOpen ? 'w-64' : 'w-20'} flex flex-col overflow-y-auto`}>
      <nav className="flex-1 px-4 py-8 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = activeTab === item.id

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-card-foreground hover:bg-secondary'
              }`}
            >
              <Icon className="h-5 w-5 flex-shrink-0" />
              {isOpen && <span className="text-sm font-medium">{item.label}</span>}
            </button>
          )
        })}
      </nav>

      <div className="p-4 border-t border-border">
        <Button variant="outline" className="w-full text-xs" size="sm">
          {isOpen ? 'Logout' : '↗'}
        </Button>
      </div>
    </aside>
  )
}
