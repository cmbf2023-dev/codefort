'use client'

import { OverviewTab } from './tabs/overview-tab'
import { GroupsTab } from './tabs/groups-tab'
import { CloningTab } from './tabs/cloning-tab'
import { AnalyticsTab } from './tabs/analytics-tab'
import { SettingsTab } from './tabs/settings-tab'
import { HelpTab } from './tabs/help-tab'

interface DashboardContentProps {
  activeTab: string
}

export function DashboardContent({ activeTab }: DashboardContentProps) {
  return (
    <div className="flex-1 overflow-auto">
      {activeTab === 'overview' && <OverviewTab />}
      {activeTab === 'groups' && <GroupsTab />}
      {activeTab === 'cloning' && <CloningTab />}
      {activeTab === 'analytics' && <AnalyticsTab />}
      {activeTab === 'settings' && <SettingsTab />}
      {activeTab === 'help' && <HelpTab />}
    </div>
  )
}
